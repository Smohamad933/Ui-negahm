"use client";

import { useRouter } from "next/navigation";

export default function LogoutButton() {
  const router = useRouter();

  async function onLogout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/dashbord/app/login");
    router.refresh();
  }

  return (
    <button onClick={onLogout} className="admin-nav-link w-full text-right">
      خروج از حساب
    </button>
  );
}
